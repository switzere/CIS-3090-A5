CIS*3090 A5
Evan Switzer
0971076

To Run:
make
oclgrind ./a5 <-n #> <-s #> <-i #>
